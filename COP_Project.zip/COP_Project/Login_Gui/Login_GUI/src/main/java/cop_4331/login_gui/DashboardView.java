/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cop_4331.login_gui;

/**
 *
 * @author fayai
 */
public class DashboardView {
    public void renderCustomerDashboardView() {
        // Rendering logic for customer dashboard view
        System.out.println("Rendering Customer Dashboard...");
        // Implement UI rendering code here
    }

    public void renderSellerDashboardView() {
        // Rendering logic for seller dashboard view
        System.out.println("Rendering Seller Dashboard...");
        // Implement UI rendering code here
    }
}

