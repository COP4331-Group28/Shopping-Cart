/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cop_4331.login_gui;

/**
 *
 * @author fayai
 */
public class DashboardController {
    private DashboardView dashboardView;

    public DashboardController() {
        this.dashboardView = new DashboardView();
    }

    public void renderCustomerDashboard() {
        // Logic to render customer dashboard view
        dashboardView.renderCustomerDashboardView();
    }

    public void renderSellerDashboard() {
        // Logic to render seller dashboard view
        dashboardView.renderSellerDashboardView();
    }
}

