/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cop_4331.login_gui;

/**
 *
 * @author fayai
 */
import javax.swing.*;

public class LoginView extends JFrame {
    public LoginView() {
        setTitle("Simple Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JButton customerButton = new JButton("Login as Customer");
        customerButton.setBounds(50, 50, 200, 30);
        add(customerButton);

        JButton sellerButton = new JButton("Login as Seller");
        sellerButton.setBounds(50, 100, 200, 30);
        add(sellerButton);

        customerButton.addActionListener(e -> {
            // Handle login as customer
            JOptionPane.showMessageDialog(null, "Logged in as Customer");
        });

        sellerButton.addActionListener(e -> {
            // Handle login as seller
            JOptionPane.showMessageDialog(null, "Logged in as Seller");
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginView loginGUI = new LoginView();
            loginGUI.setVisible(true);
        });
    }
}



