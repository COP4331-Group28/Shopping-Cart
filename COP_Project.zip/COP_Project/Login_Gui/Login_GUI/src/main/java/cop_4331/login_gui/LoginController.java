/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cop_4331.login_gui;

/**
 *
 * @author fayai
 */
public class LoginController {
    private DashboardController dashboardController;

    public LoginController() {
        this.dashboardController = new DashboardController();
    }

    public void handleCustomerLogin() {
        // Render customer dashboard view
        dashboardController.renderCustomerDashboard();
    }

    public void handleSellerLogin() {
        // Render seller dashboard view
        dashboardController.renderSellerDashboard();
    }
}

