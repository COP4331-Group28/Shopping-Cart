/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cop_4331.login_gui;

/**
 *
 * @author gerre
 */
public class Login_GUI {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
